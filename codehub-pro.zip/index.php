<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeHub Pro - Elite Demo</title>
    <style>
        /* كود الـ CSS اللي كتبناه في style.css */
        :root { --primary: #2563eb; --dark: #0f172a; --bg: #f8fafc; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: sans-serif; }
        body { background-color: var(--bg); color: var(--dark); }
        header { background: #fff; padding: 20px 5%; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 1000; }
        .logo { font-size: 1.5rem; font-weight: 800; color: var(--primary); letter-spacing: -1px; }
        .container { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; padding: 40px 5%; max-width: 1200px; margin: auto; }
        .card { background: #fff; border-radius: 20px; padding: 20px; transition: 0.3s; border: 1px solid #f1f5f9; text-align: center; }
        .card:hover { transform: translateY(-10px); box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
        .price { color: var(--primary); font-weight: 900; font-size: 1.5rem; margin: 15px 0; display: block; }
        .buy-btn { background: var(--primary); color: white; border: none; padding: 12px 25px; border-radius: 12px; font-weight: bold; cursor: pointer; width: 100%; }
        footer { margin-top: 4rem; background: var(--dark); color: #fff; padding: 3rem 1rem; text-align: center; border-top: 5px solid var(--primary); }
    </style>
</head>
<body>

    <header>
        <div class="logo">CODEHUB.PRO</div>
        <div style="font-size: 1.5rem;">🛒</div>
    </header>

    <section style="text-align: center; padding: 60px 20px; background: white;">
        <h1 style="font-size: 2.5rem; font-weight: 900;">Next-Gen Digital Store</h1>
        <p style="color: #64748b; margin-top: 10px;">The official CodeHub template for high-converting marketplaces.</p>
    </section>

    <div class="container">
        <div class="card">
            <div style="height: 180px; background: #f1f5f9; border-radius: 15px; margin-bottom: 20px;"></div>
            <h2>Titan Engine V2</h2>
            <p style="color: #64748b; font-size: 0.9rem;">Automated data scraping at your fingertips.</p>
            <span class="price">$59.00</span>
            <button class="buy-btn">Buy License</button>
        </div>
        
        <div class="card">
            <div style="height: 180px; background: #f1f5f9; border-radius: 15px; margin-bottom: 20px;"></div>
            <h2>CodeHub UI Kit</h2>
            <p style="color: #64748b; font-size: 0.9rem;">Premium components for modern web apps.</p>
            <span class="price">$29.00</span>
            <button class="buy-btn">Buy License</button>
        </div>
    </div>

    <footer>
        <p>This Elite Product is Crafted by</p>
        <h2 style="color: var(--primary); margin: 10px 0;">CODEHUB ENGINEERING</h2>
        <p style="opacity: 0.5; font-size: 0.8rem;">© 2026 Powered by Titan Search Engine</p>
    </footer>

</body>
</html>

