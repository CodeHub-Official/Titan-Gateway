Welcome to CodeHub Pro v1.0.0
-----------------------------
Thank you for purchasing the elite WordPress theme.
Installation:
1. Go to WordPress Dashboard > Appearance > Themes.
2. Click 'Add New' > 'Upload Theme'.
3. Select 'codehub-pro.zip' and click Install.
4. Activate and enjoy the speed!

Support: support@codehub.com
Crafted by CodeHub Engineering Team.

