<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Helpshift</title>

    <link rel="shortcut icon" href="/static/images/favicon.ico" />
    <link rel="stylesheet" href="/static/css/login.css">
    <link rel="stylesheet" href="/static/css/tailwind.css">

    <script>var HSM = {"cloud_service":"s3","features":{"i18n_enabled":false},"default_bot_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/bot/240.png","show_webchat":false,"default_app_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/app/240.png","dev_mode":false,"ws_origin":"TQj4H5PTspXQsrlLDh8NSeWHegeS4z+zTK/EVFJGmew=--31/kNZvJJqkAnAtcUbYiWy1C+Vb5nAq8bLb0eyocmaU=","comboUrl":"","default_agent_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/agent/240.png","profileId":"playrix_profile_20160831170005802-dc94299328aae8a","csrf":"UUc6r_V8gOLf13aRmJfYTYVwUhSYDbH_WaRJ4sFRTgw","domain":"playrix","ws_endpoint":"wss://ws-nv.helpshift.com"};</script>
    <script>
      window.gtmDataLayer = window.gtmDataLayer || [];
      window.dataLayer = [];
    </script>
  </head>
  <body>

    <!-- Google Tag Manager -->
    <script>
      // Loaded after the dashboard page finishes document ready because
      // YUI router waits for the document ready event and the event is delayed
      // because of the scripts loaded by gtm
      document.onreadystatechange = function () {
        if (document.readyState === "complete") {
          window.setTimeout (function () {
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','gtmDataLayer','GTM-KHDTN3');
          }, 1000);
        }
      }
    </script>
    <!-- End Google Tag Manager -->

    <div class="hs-login-page
">
      <header class="hs-login-page__header">
        <h1 class="no-margin">Playrix</h1>
      </header>

      <div class="hs-login-form-box">
        <form id="login-form" class="hs-login-form" action="/login/" method="POST"
               novalidate>

          <h3 class="hs-login-page__login-header" id="login-page-header">Log in to your account</h3>

          <div class="hs-formfield">
            <label for="username" class="hs-formfield__label" id="email-formfield-label">Email Address</label>
            <input data-qa="login__username" id="username" type="email" name="username"
                   title="Email address" placeholder="Enter email address" autofocus />
            <div id="username-error" class="hs-formfield__error" style="display:none">
              Email is a required field
            </div>
          </div>

          <div class="hs-formfield">
            <label for="password" class="hs-formfield__label" id="passowrd-formfield-label">Password</label>
            <input data-qa="login__pwd" id="password" type="password" name="password" title="Password"
                   placeholder="Enter password" />
            <div id="password-error" class="hs-formfield__error"
                   style="display:none">
              
            </div>
          </div>



          <div class="hs-login-page__remember-me-wrapper">
            <label class="hs-checkbox">
              <input name="remember-session" type="checkbox" class="hs-checkbox__input" value="on" />
              <span class="hs-checkbox__fake-box">
                <i class="ion-tick"></i>
              </span>
              <span class="hs-checkbox__label" id="remember-me-option-label">
                Remember me on this computer for 7 days
              </span>
            </label>
          </div>

          <input type="hidden" value="UUc6r_V8gOLf13aRmJfYTYVwUhSYDbH_WaRJ4sFRTgw" name="_csrf_token" />
          <input type="hidden" value="https://playrix.helpshift.com/wp-config.php/" name="next" />

          <button class="hs-button hs-button--expanded" id="login-submit-button" data-qa="login__submit">Log In To My Account</button>

          <div class="hs-login-page__forgot-password-wrapper">
            <strong>
              <a class="hs-link" id="forgot-password-link">
                Forgot Password
              </a>
            </strong>
          </div>
        </form>

        <form id="forgot-password-form" action="/login/forgot/" method="POST"
              style="display:none;" novalidate>
          <h3 class="hs-login-page__login-header" id="forget-password-header">Forgot Password</h3>
          <p id="forget-password-description">Enter the email address you use to log in with, and we will send you a link to reset your password.</p>

          <div class="hs-formfield">
            <label for="email-address" class="hs-formfield__label" id="email-formfield-label">Email Address</label>
            <input id="email-address" type="email" name="email"
                   title="Email address" placeholder="Enter email address" autofocus />
            <div id="forgot-email-error" class="hs-formfield__error" style="display:none">
            Email is a required field
            </div>
          </div>


          <input type="hidden" value="UUc6r_V8gOLf13aRmJfYTYVwUhSYDbH_WaRJ4sFRTgw" name="_csrf_token" />
          <input type="hidden" value="https://playrix.helpshift.com/wp-config.php/" name="next" />

          <button class="hs-button hs-button--expanded" id="send-reset-link-btn">Send Reset Link</button>
          <div class="hs-login-page__forgot-password-wrapper">
            <strong>
              <a id="login-link" class="hs-link hs-link--icon-left">
                <i class="ion-arrow-thin-left hs-link__icon"></i>
                <span id="back-to-login-link">Back to Login</span>
              </a>
            </strong>
          </div>
        </form>

        <div class="hs-third-party-login">
          <span id="other-login-header">or login with:</span>
          <div class="hs-third-party-login__forms">
            <form action="/login/google/" method="POST" class="hs-third-party-login__form">
              <input type="hidden" value="UUc6r_V8gOLf13aRmJfYTYVwUhSYDbH_WaRJ4sFRTgw" name="_csrf_token" />
              <input type="hidden" value="https://playrix.helpshift.com/wp-config.php/" name="next" />
              <input type="hidden" id="google-login-language" value="en" name="user-lang" />
              <button class="hs-button hs-button--x-small hs-button--hollow hs-button--icon-left">
                <i class="ion-google hs-button__icon"></i>
                <span class="hs-button__text" id="google-option">Google</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      </div>

    </div>

    <footer class="hs-login-page__footer">
      <div class="hs-powered-by">
        <a class="hs-powered-by__link" href="https://www.helpshift.com"
           target="_blank"
           title="Helpshift">Helpshift</a>
      </div>
      <div class="hs-privacy-policy" style="margin-bottom: 6rem;">
        <a id="privacy-policy-link" class="hs-privacy-policy__link tw-text-blue-300" target="_blank"
           href="https://www.helpshift.com/legal/privacy/" title="Privacy Policy">
          <small>
            <strong id="privacy-policy-text">Privacy Policy</strong>
          </small>
        </a>
      </div>
      <div id="language-options-container" class="tw-fixed tw-bottom-0 tw-w-full tw-bg-gray-600 tw-border-t tw-border-gray-300 tw-p-16 tw-text-center tw-shadow-md ">
          <div id="language-selector" class="tw-flex tw-justify-center tw-text-[12px] tw-text-black-300 tw-gap-20"></div>
      </div>    </footer>

    <!-- nocache=true will set value of response header Cache-Control="no-cache". This is configured via nginx -->
    <script src="//s.helpshift.com/static/bundles/login/login.min.js?nocache=true" async></script>

    <!-- Typekit -->
    <script>
      (function(d) {
        var config = {
          kitId: 'vcn6kqr',
          scriptTimeout: 3000,
          async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
      })(document);
    </script>

    <script type="text/javascript">
      window.gtmDataLayer.push ({
        "cnameSuffix": "helpshift.com"
      });
    </script>
  </body>
</html>
