<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Helpshift</title>

    <link rel="shortcut icon" href="/static/images/favicon.ico" />
    <link rel="stylesheet" href="/static/css/login.css">
    <link rel="stylesheet" href="/static/css/tailwind.css">

    <script>var HSM = {"cloud_service":"s3","features":{"i18n_enabled":false},"default_bot_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/bot/240.png","show_webchat":false,"default_app_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/app/240.png","dev_mode":false,"ws_origin":"+1XBLMii1R4cveo/gBOMxuZ6s9EuMklWw+e9dUoV3XY=--fcQF0BN9bHBoGp74KddVqkytD3Y3Tc6CYLWZ3Zjg4As=","comboUrl":"","default_agent_avatar":"https://s3.amazonaws.com/assets.helpshift.com/default-avatars/avatar/agent/240.png","profileId":"supercell_profile_20140122071247076-ae2f5e287891dc2","csrf":"eluKYurq-GmfIEbNTArUdl8xUX-Bxr13lQrwGqXyZKE","domain":"supercell","ws_endpoint":"wss://ws-nv.helpshift.com"};</script>
    <script>
      window.gtmDataLayer = window.gtmDataLayer || [];
      window.dataLayer = [];
    </script>
  </head>
  <body>

    <!-- Google Tag Manager -->
    <script>
      // Loaded after the dashboard page finishes document ready because
      // YUI router waits for the document ready event and the event is delayed
      // because of the scripts loaded by gtm
      document.onreadystatechange = function () {
        if (document.readyState === "complete") {
          window.setTimeout (function () {
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','gtmDataLayer','GTM-KHDTN3');
          }, 1000);
        }
      }
    </script>
    <!-- End Google Tag Manager -->

    <div class="hs-login-page
       hs-login-page--sso-only-login 
      ">
      <header class="hs-login-page__header">
        <h1 class="no-margin">Supercell</h1>
      </header>


      <div class="hs-login-form-box">
        <h3 class="hs-login-page__login-header">
          <span id="single-login-title">Log in to your account</span>
        </h3>
        <div class="hs-third-party-login hs-third-party-login--sso
         hs-third-party-login--sso-only-login ">
          <div class="hs-third-party-login__forms">

            <form action="/login/saml/idp-login/" method="POST" class="hs-third-party-login__form">
              <input type="hidden" value="eluKYurq-GmfIEbNTArUdl8xUX-Bxr13lQrwGqXyZKE" name="_csrf_token" />
              <input type="hidden" value="https://supercell.helpshift.com/config.php/" name="next" />
              <button class="hs-button
                             
                             hs-button--icon-left">
                <i class="ion-okta hs-button__icon"></i>
                <span class="hs-button__text">Okta</span>
              </button>
            </form>



          </div>
        </div>
      </div>

    </div>

    <footer class="hs-login-page__footer">
      <div class="hs-powered-by">
        <a class="hs-powered-by__link" href="https://www.helpshift.com"
           target="_blank"
           title="Helpshift">Helpshift</a>
      </div>
      <div class="hs-privacy-policy" style="margin-bottom: 6rem;">
        <a id="privacy-policy-link" class="hs-privacy-policy__link tw-text-blue-300" target="_blank"
           href="https://www.helpshift.com/legal/privacy/" title="Privacy Policy">
          <small>
            <strong id="privacy-policy-text">Privacy Policy</strong>
          </small>
        </a>
      </div>
      <div id="language-options-container" class="tw-fixed tw-bottom-0 tw-w-full tw-bg-gray-600 tw-border-t tw-border-gray-300 tw-p-16 tw-text-center tw-shadow-md ">
          <div id="language-selector" class="tw-flex tw-justify-center tw-text-[12px] tw-text-black-300 tw-gap-20"></div>
      </div>    </footer>


    <!-- Typekit -->
    <script>
      (function(d) {
        var config = {
          kitId: 'vcn6kqr',
          scriptTimeout: 3000,
          async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
      })(document);
    </script>

    <script type="text/javascript">
      window.gtmDataLayer.push ({
        "cnameSuffix": "helpshift.com"
      });
    </script>
  </body>
</html>
